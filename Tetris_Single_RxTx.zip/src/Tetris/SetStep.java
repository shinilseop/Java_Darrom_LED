package Tetris;

public interface SetStep {
	public void setStep(int nextStep);
}
