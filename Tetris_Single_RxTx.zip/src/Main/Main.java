package Main;

import UI.UIManager;

public class Main {
	public static boolean isRun=false;
	public static void main(String args[]) {
		UIManager uim=new UIManager();
		uim.start();
	}
} 