package DBMS;

public class User {
	private String id;
	private int score;
	private String time;
	public String getId() {
		return id;
	}
	public void setName(String id) {
		this.id = id;
	}
	public int getScore() {
		return score;
	}
	public void setScore(int score) {
		this.score = score;
	}
	public String getTime() {
		return time;
	}
	public void setTime(String time) {
		this.time = time;
	}
	
}
